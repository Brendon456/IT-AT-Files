﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AnalogClock
{
    public class AnalogClockFeatures
    {
        public void Timer()
        {
            //Displays the time of the clock.

            int WIDTH = 300 , HEIGHT = 300 , secHAND = 140 , minHAND = 11;
            //sets the size of the clock. The hour hand, mini hand, and second hand.
            
            int cx, cy;

            
          
        }

        private void t_Tick()
        {
            
        }

        private int msCoord()
        {
            //coordinate for minute and second hand.
        }

        public void hrCoord()
        {
            //coordinates for hour hand.
        }
    }
}