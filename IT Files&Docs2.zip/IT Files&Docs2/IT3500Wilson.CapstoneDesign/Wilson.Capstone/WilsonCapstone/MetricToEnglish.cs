﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WilsonCapstone
{
    public class MetricToEnglish
    {
        public double getFeet()
        {
            
        }

        public double getInches()
        {
            
        }

        public double getMeters()
        {
            
        }

        public double getYards()
        {
            
        }

        public double roundToFirstDecimal()
        {
            throw new System.NotImplementedException();
        }
    }
}