﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WilsonCapstone
{   
    public class EnglishToMetric
    {
    
    public int miles;
        public int yards;
        public int feet;
        public double inches;
        private int convertedYards;
        private int convertedFeet;
        private double convertedInches;
        private double centimeters;
        private int meters;
        private int kilometers;

        public EnglishToMetric(int miles, int yards, int feet, int meters, int kilometers)
        {
            
       

        }

        private int milesToYards()
        {
            convertedYards = miles * 1760;
        }

        private int yardsToFeet()
        {
            convertedFeet = (convertedYards + yards) * 3;
        }

        private int feetToInches()
        {
            convertedInches = (convertedFeet + feet) * 12;
            inches = convertedInches + inches;
            

        }
           
        private int inchesToCentimeters()
        {
            centimeters = inches * 2.53;
        }

        private int centimetersToKilometers()
        {
            double temp  = centimeters / 100000;
            kilometers = (int)temp / 1;
        }

        private int getRemainingCentimetersFromKilometer()
        {
            centimeters = centimeters - (kilometers * 100000);
        }
        private int convertCentimetersToMeters()
        {
            double temp = centimeters / 100;
            meters = (int)temp / 1;
        }
        
        private int RemainingCentimetersToMeters()
        {
            centimeters = centimeters - (meters * 100);
        }
        public string getCentimeters()
        {
            return centimeters.ToString();
        }

        public string getKilometers()
        {
            return kilometers.ToString();
        }

        public string getMeters()
        {
            return meters.ToString(); 
        }

        public double roundToFirstDecimalPlace(int miles, int yards, int feet, int meters, int kilometers)
        {
           
        }

        public bool setFeet(int miles, int yards, int feet, int meters, int kilometers)
        {
            
        }

        public bool setInches(int miles, int yards, int feet, int meters, int kilometers)
        {
            
        }

        public bool setMiles(int miles, int yards, int feet, int meters, int kilometers)
        {
            
        }

        public bool setYards(int miles, int yards, int feet, int meters, int kilometers)
        {
            
        }

        public bool validateForDigitsOnly()
        {
            throw new System.NotImplementedException();
        }
    }
}