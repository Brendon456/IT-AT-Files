﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudetnsDemoInheritanceAndOverRiding
{
    class Student
    {
        private String name;
        private DateTime birthdate;
        private char gender;

        public Student()//Overloading
        {
            Console.WriteLine("Student() constructor running");
        }

        public Student(String s)//Overloading
        {
            Console.WriteLine("Student(String) constructor running");
            name = s;
        }

        public Student(String s, DateTime d)//Overloading
        {
            Console.WriteLine("Student(String, DateTime) constructor running");
            name = s;
            birthdate = d;
        }

        public bool setName(String s)
        {
            Console.WriteLine("Student's version of setName() is running");
            if(s != null && s.Length>0)
            {
                name = s;
                return true;
            }
            return false;
        }

        public String getName()
        {
            Console.WriteLine("Student's version of getName() is running");
            if (name != null && name.Length > 0)
                return name;
            else
                return "name not initialized";
        }

        public bool setBirthdate(DateTime d)
        {
            Console.WriteLine("Student's version of setBirthdate() is running");
            birthdate = d;
            return true;
        }

        public DateTime getBirthdate()
        {
            Console.WriteLine("Student's version of getBirthdate() is running");
            return birthdate;
        }

        public bool setGender(String s)
        {
            Console.WriteLine("Student's version of setGender() is running");
            gender = s[0];
            return true;
        }

        public String getGender()
        {
            Console.WriteLine("Student's version of getGender() is running");
            return gender.ToString();
        }
    }
}
