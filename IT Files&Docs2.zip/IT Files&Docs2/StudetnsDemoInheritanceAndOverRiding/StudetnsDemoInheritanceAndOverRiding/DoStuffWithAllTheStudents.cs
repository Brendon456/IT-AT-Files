﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudetnsDemoInheritanceAndOverRiding
{
    class DoStuffWithAllTheStudents
    {
        public DoStuffWithAllTheStudents()
        {
            CollegeStudent bob = new CollegeStudent();

            bob.setName("bob");
            bob.setGender("male");
            bob.setIDNumber("@123456789");

            Console.WriteLine("bob's name is " + bob.getName());
            Console.WriteLine("bob's gender is " + bob.getGender());
            Console.WriteLine("bob's ID number is " + bob.getIDNumber());

            Console.WriteLine();

            CollegeStudent sara = new CollegeStudent("@987654321");

            sara.setName("sara");
            sara.setGender("female");
            //sara.setIDNumber("@987654321");

            Console.WriteLine("sara's name is " + sara.getName());
            Console.WriteLine("sara's gender is " + sara.getGender());
            Console.WriteLine("sara's ID number is " + sara.getIDNumber());

            Console.WriteLine();

            Console.WriteLine("bob's name is " + bob.getName());
            Console.WriteLine("bob's gender is " + bob.getGender());
            Console.WriteLine("bob's ID number is " + bob.getIDNumber());
        }
    }
}
