﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StudetnsDemoInheritanceAndOverRiding
{
    class CollegeStudent  :  Student
    {
        private String name;
        private DateTime birthdate;
        private char gender;
        private String IDNumber;
        private String major;

        public CollegeStudent()
        {
            Console.WriteLine("CollegeStudent() constructor running");
        }

        public CollegeStudent(String s)
        {
            Console.WriteLine("CollegeStudent(String) constructor running");
            IDNumber = s;
        }

        public bool setIDNumber(String s)
        {
            //using Curry ID as the pattern

            //must be 10 chars long
            //must begin with '@'
            if (s.Length==10 && s[0]=='@')
            {
                //all other chars must be digits
                for (int n = 1; n < 10; n++)
                    if (s[n] < '0' || s[n] > '9')
                        return false;
                
                return true;
            }

            return false;
        }

        public String getIDNumber()
        {
            return IDNumber;
        }

        public bool setMajor(String s)
        {
            major = s;
            return true;
        }

        public String getMajor()
        {
            return major;
        }
/*
        //*****************************************************************
        public bool setName(String s)
        {
            if (s != null && s.Length > 0)
            {
                name = s;
                return true;
            }
            return false;
        }

        public String getName()
        {
            if (name != null && name.Length > 0)
                return name;
            else
                return "name not initialized";
        }

        public bool setBirthdate(DateTime d)
        {
            birthdate = d;
            return true;
        }

        public DateTime getBirthdate()
        {
            return birthdate;
        }

        public bool setGender(String s)
        {
            gender = s[0];
            return true;
        }

        public String getGender()
        {
            return gender.ToString();
        }
        //******************************************************************
        */
    }
}
