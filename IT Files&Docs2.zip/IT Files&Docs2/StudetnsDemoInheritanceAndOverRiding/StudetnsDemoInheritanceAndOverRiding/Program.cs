﻿using System;

namespace StudetnsDemoInheritanceAndOverRiding
{
    class Program
    {
        static void Main(string[] args)
        {
            new DoStuffWithAllTheStudents();
        }
    }
}
