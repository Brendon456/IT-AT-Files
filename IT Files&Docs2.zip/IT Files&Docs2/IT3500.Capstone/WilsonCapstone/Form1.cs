﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WilsonCapstone
{
    public partial class frmEnglishToMetric : Form
    {
        public frmEnglishToMetric()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }



        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (optEnglish.Checked)
            {
                EnglishToMetric etm = new EnglishToMetric(txtMiles.Text, txtYards.Text, txtFeet.Text, txtInches.Text);

                txtKilometers.Text = etm.getKilometers();
                txtMeters.Text = etm.getMeters();
                txtCentimeters.Text = etm.getCentimeters();
            }
            else if (optMetric.Checked)
            {
                MetricToEnglish mte = new MetricToEnglish(txtKilometers.Text, txtMeters.Text, txtCentimeters.Text);

                txtMiles.Text = mte.getMiles();
                txtYards.Text = mte.getYards();
                txtFeet.Text = mte.getFeet();
                txtInches.Text = mte.getInches();
            }
        }

        private void frmEnglishToMetric_Load(object sender, EventArgs e)
        {

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtKilometers.Text = "";
            txtMeters.Text = "";
            txtCentimeters.Text = "";
            txtMiles.Text = "";
            txtYards.Text = "";
            txtFeet.Text = "";
            txtInches.Text = "";        
                }

        private void optEnglish_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
