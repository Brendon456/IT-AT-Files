﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WilsonCapstone
{   
    public class EnglishToMetric
    {
        private int convertedYards;
        private int convertedFeet;
        private double convertedInches;
        private double centimeters; 
        private int meters;
        private int kilometers;

        public EnglishToMetric(String miles, String yards, String feet, String inches)
        {
            convertedYards = milesToYards(Convert.ToInt16(miles)) + Convert.ToInt16(yards);
            convertedFeet = yardsToFeet(convertedYards) + Convert.ToInt16(feet);
            convertedInches = feetToInches(convertedFeet) + Convert.ToDouble(inches);
            centimeters = inchesToCentimeters(convertedInches);
            kilometers = centimetersToKilometers(centimeters);
            centimeters = getRemainingCentimetersFromKilometer(kilometers);
            meters = convertCentimetersToMeters(centimeters);
            centimeters = getRemainingCentimetersFromMeters(meters);

            





        }

        private int milesToYards(int _miles)
        {
            return _miles * 1760;
        }

        private int yardsToFeet(int _yards)
        {
            return (convertedYards + _yards) * 3;
        }

        private double feetToInches(int _feet)
        {
            return _feet * 12;
        }

        private double inchesToCentimeters(double _inches)
        {
            return _inches * 2.53;
        }

        private int centimetersToKilometers(double _centimeters)
        {
            double temp  = _centimeters / 100000;
            return (int)temp;
        }

        private double getRemainingCentimetersFromKilometer(int _kilometers)
        {
            return centimeters - (_kilometers * 100000);
        }
        private int convertCentimetersToMeters(double _centimeters)
        {
            double temp = _centimeters / 100;
            return (int)temp / 1;
        }
        
        private double getRemainingCentimetersFromMeters(int _meters)
        {
            return centimeters - (_meters * 100);
        }
        public string getCentimeters()
        {
            return Math.Round(centimeters, 1).ToString();
        }

        public string getKilometers()
        {
            return kilometers.ToString();
        }

        public string getMeters()
        {
            return meters.ToString(); 
        }

        

       
    }
}