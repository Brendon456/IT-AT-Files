﻿namespace WilsonCapstone
{
    partial class frmEnglishToMetric
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMiles = new System.Windows.Forms.TextBox();
            this.lblMiles = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblYards = new System.Windows.Forms.Label();
            this.txtYards = new System.Windows.Forms.TextBox();
            this.lblFeet = new System.Windows.Forms.Label();
            this.txtFeet = new System.Windows.Forms.TextBox();
            this.lblInches = new System.Windows.Forms.Label();
            this.txtInches = new System.Windows.Forms.TextBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.txtCentimeters = new System.Windows.Forms.TextBox();
            this.txtMeters = new System.Windows.Forms.TextBox();
            this.txtKilometers = new System.Windows.Forms.TextBox();
            this.lblKilometers = new System.Windows.Forms.Label();
            this.lblMeters = new System.Windows.Forms.Label();
            this.lblCentimeters = new System.Windows.Forms.Label();
            this.optEnglish = new System.Windows.Forms.RadioButton();
            this.optMetric = new System.Windows.Forms.RadioButton();
            this.SuspendLayout();
            // 
            // txtMiles
            // 
            this.txtMiles.Location = new System.Drawing.Point(598, 59);
            this.txtMiles.Name = "txtMiles";
            this.txtMiles.Size = new System.Drawing.Size(130, 26);
            this.txtMiles.TabIndex = 0;
            this.txtMiles.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblMiles
            // 
            this.lblMiles.AutoSize = true;
            this.lblMiles.Location = new System.Drawing.Point(505, 61);
            this.lblMiles.Name = "lblMiles";
            this.lblMiles.Size = new System.Drawing.Size(45, 20);
            this.lblMiles.TabIndex = 1;
            this.lblMiles.Text = "Miles";
            this.lblMiles.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(611, 45);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 20);
            this.label2.TabIndex = 2;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblYards
            // 
            this.lblYards.AutoSize = true;
            this.lblYards.Location = new System.Drawing.Point(505, 121);
            this.lblYards.Name = "lblYards";
            this.lblYards.Size = new System.Drawing.Size(51, 20);
            this.lblYards.TabIndex = 4;
            this.lblYards.Text = "Yards";
            // 
            // txtYards
            // 
            this.txtYards.Location = new System.Drawing.Point(598, 115);
            this.txtYards.Name = "txtYards";
            this.txtYards.Size = new System.Drawing.Size(130, 26);
            this.txtYards.TabIndex = 5;
            // 
            // lblFeet
            // 
            this.lblFeet.AutoSize = true;
            this.lblFeet.Location = new System.Drawing.Point(508, 191);
            this.lblFeet.Name = "lblFeet";
            this.lblFeet.Size = new System.Drawing.Size(42, 20);
            this.lblFeet.TabIndex = 6;
            this.lblFeet.Text = "Feet";
            // 
            // txtFeet
            // 
            this.txtFeet.Location = new System.Drawing.Point(598, 185);
            this.txtFeet.Name = "txtFeet";
            this.txtFeet.Size = new System.Drawing.Size(130, 26);
            this.txtFeet.TabIndex = 7;
            // 
            // lblInches
            // 
            this.lblInches.AutoSize = true;
            this.lblInches.Location = new System.Drawing.Point(508, 252);
            this.lblInches.Name = "lblInches";
            this.lblInches.Size = new System.Drawing.Size(57, 20);
            this.lblInches.TabIndex = 8;
            this.lblInches.Text = "Inches";
            // 
            // txtInches
            // 
            this.txtInches.Location = new System.Drawing.Point(598, 252);
            this.txtInches.Name = "txtInches";
            this.txtInches.Size = new System.Drawing.Size(130, 26);
            this.txtInches.TabIndex = 9;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(51, 381);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(84, 41);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnEnter
            // 
            this.btnEnter.Location = new System.Drawing.Point(60, 271);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 38);
            this.btnEnter.TabIndex = 11;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(60, 327);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 39);
            this.btnReset.TabIndex = 12;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // txtCentimeters
            // 
            this.txtCentimeters.Location = new System.Drawing.Point(331, 191);
            this.txtCentimeters.Name = "txtCentimeters";
            this.txtCentimeters.Size = new System.Drawing.Size(132, 26);
            this.txtCentimeters.TabIndex = 13;
            // 
            // txtMeters
            // 
            this.txtMeters.Location = new System.Drawing.Point(331, 115);
            this.txtMeters.Name = "txtMeters";
            this.txtMeters.Size = new System.Drawing.Size(132, 26);
            this.txtMeters.TabIndex = 14;
            this.txtMeters.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // txtKilometers
            // 
            this.txtKilometers.Location = new System.Drawing.Point(331, 61);
            this.txtKilometers.Name = "txtKilometers";
            this.txtKilometers.Size = new System.Drawing.Size(132, 26);
            this.txtKilometers.TabIndex = 15;
            // 
            // lblKilometers
            // 
            this.lblKilometers.AutoSize = true;
            this.lblKilometers.Location = new System.Drawing.Point(225, 61);
            this.lblKilometers.Name = "lblKilometers";
            this.lblKilometers.Size = new System.Drawing.Size(83, 20);
            this.lblKilometers.TabIndex = 16;
            this.lblKilometers.Text = "Kilometers";
            // 
            // lblMeters
            // 
            this.lblMeters.AutoSize = true;
            this.lblMeters.Location = new System.Drawing.Point(235, 115);
            this.lblMeters.Name = "lblMeters";
            this.lblMeters.Size = new System.Drawing.Size(58, 20);
            this.lblMeters.TabIndex = 17;
            this.lblMeters.Text = "Meters";
            // 
            // lblCentimeters
            // 
            this.lblCentimeters.AutoSize = true;
            this.lblCentimeters.Location = new System.Drawing.Point(213, 194);
            this.lblCentimeters.Name = "lblCentimeters";
            this.lblCentimeters.Size = new System.Drawing.Size(95, 20);
            this.lblCentimeters.TabIndex = 18;
            this.lblCentimeters.Text = "Centimeters";
            // 
            // optEnglish
            // 
            this.optEnglish.AutoSize = true;
            this.optEnglish.Location = new System.Drawing.Point(28, 121);
            this.optEnglish.Name = "optEnglish";
            this.optEnglish.Size = new System.Drawing.Size(147, 24);
            this.optEnglish.TabIndex = 19;
            this.optEnglish.TabStop = true;
            this.optEnglish.Text = "EnglishToMetric";
            this.optEnglish.UseVisualStyleBackColor = true;
            this.optEnglish.CheckedChanged += new System.EventHandler(this.optEnglish_CheckedChanged);
            // 
            // optMetric
            // 
            this.optMetric.AutoSize = true;
            this.optMetric.Location = new System.Drawing.Point(28, 194);
            this.optMetric.Name = "optMetric";
            this.optMetric.Size = new System.Drawing.Size(147, 24);
            this.optMetric.TabIndex = 20;
            this.optMetric.TabStop = true;
            this.optMetric.Text = "MetricToEnglish";
            this.optMetric.UseVisualStyleBackColor = true;
            // 
            // frmEnglishToMetric
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.optMetric);
            this.Controls.Add(this.optEnglish);
            this.Controls.Add(this.lblCentimeters);
            this.Controls.Add(this.lblMeters);
            this.Controls.Add(this.lblKilometers);
            this.Controls.Add(this.txtKilometers);
            this.Controls.Add(this.txtMeters);
            this.Controls.Add(this.txtCentimeters);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.txtInches);
            this.Controls.Add(this.lblInches);
            this.Controls.Add(this.txtFeet);
            this.Controls.Add(this.lblFeet);
            this.Controls.Add(this.txtYards);
            this.Controls.Add(this.lblYards);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblMiles);
            this.Controls.Add(this.txtMiles);
            this.Name = "frmEnglishToMetric";
            this.Text = " ";
            this.Load += new System.EventHandler(this.frmEnglishToMetric_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMiles;
        private System.Windows.Forms.Label lblMiles;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblYards;
        private System.Windows.Forms.TextBox txtYards;
        private System.Windows.Forms.Label lblFeet;
        private System.Windows.Forms.TextBox txtFeet;
        private System.Windows.Forms.Label lblInches;
        private System.Windows.Forms.TextBox txtInches;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.TextBox txtCentimeters;
        private System.Windows.Forms.TextBox txtMeters;
        private System.Windows.Forms.TextBox txtKilometers;
        private System.Windows.Forms.Label lblKilometers;
        private System.Windows.Forms.Label lblMeters;
        private System.Windows.Forms.Label lblCentimeters;
        private System.Windows.Forms.RadioButton optEnglish;
        private System.Windows.Forms.RadioButton optMetric;
    }
}

