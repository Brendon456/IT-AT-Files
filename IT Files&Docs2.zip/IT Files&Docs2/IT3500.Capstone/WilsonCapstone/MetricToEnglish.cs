﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WilsonCapstone
{
    public class MetricToEnglish
    {
        private int convertedmeters;
        private double convertedcentimeters;
        private double inches;
        private int feet;
        private int yards;
        private int miles;
        public MetricToEnglish(String _kilometers, String _meters, String _centimeters)
        {
            convertedmeters = kilometersToMeters(Convert.ToInt16(_kilometers)) + Convert.ToInt16(_meters);
            convertedcentimeters = metersToCentimeters(convertedmeters) + Convert.ToDouble(_centimeters);
            inches = centimetersToInches(convertedcentimeters);
            miles = inchesToMiles(inches);
            inches = getRemainingInchesFromMiles(miles);
            yards = convertInchesToYards(inches);
            inches = getRemainingInchesFromYards(yards);
            feet = convertInchesToFeet(inches);
            inches = getRemainingInchesFromFeet(feet);
        }

        public int kilometersToMeters(int _kilometers)
        {
            return _kilometers * 1000;
        }

        public int metersToCentimeters(double _meters)
        {
            return (int) _meters * 100;
        }

        private double centimetersToInches(double _centimeters)
        {
            return _centimeters / 2.54;
        }

        private int inchesToMiles(double _inches)
        {
            return (int) _inches / 63360;
        }

        private double getRemainingInchesFromMiles(int _miles)
        {
            return inches - (_miles * 63360);
        }

        private int convertInchesToYards(double _inches)
        {
            double temp = _inches / 36;
            return (int)temp / 1;
        }

        private double getRemainingInchesFromYards(int _yards)
        {
            return inches - (_yards * 36);
        }

        private int convertInchesToFeet(double _inches)
        {
            return  (int) _inches / 12;
          
        }

        private double getRemainingInchesFromFeet (int _feet)
        {
            return inches - (feet * 12);
        }

        public string getMiles()
        {
            return Convert.ToString(miles);
        }

        public string getYards()
        {
            return Convert.ToString(yards);
        }

        public string getFeet()
        {
            return Convert.ToString(feet);
        }

        public string getInches()
        {
            return Convert.ToString(Math.Round(inches, 1).ToString());
        }


    }
}